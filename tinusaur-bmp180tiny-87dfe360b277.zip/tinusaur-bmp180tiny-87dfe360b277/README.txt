BMP180TINY - BMP180 Barometric Pressure/Temperature/Altitude Sensor library

-----------------------------------------------------------------------------------
 Copyright (c) 2016 Neven Boyanov, Tinusaur Team. All Rights Reserved.
 Distributed as open source software under MIT License, see LICENSE.txt file.
 Please, as a favor, retain the link http://tinusaur.org to The Tinusaur Project.
-----------------------------------------------------------------------------------

This library is written in plain C.


==== Links ====

Official Tinusaur Project website: http://tinusaur.org
Project BMP180TINY page: http://tinusaur.org/projects/bmp180tiny/
Project BMP180TINY source code: https://bitbucket.org/tinusaur/bmp180tiny

Twitter: https://twitter.com/tinusaur
Facebook: https://www.facebook.com/tinusaur

