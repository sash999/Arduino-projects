/**
 * BMP180TINY - BMP180 Barometric Pressure/Temperature/Altitude Sensor library
 *
 * @created: 2015-02-25
 * @author: Neven Boyanov
 *
 * This is part of the Tinusaur/BMP180TINY project.
 *
 * Copyright (c) 2016 Neven Boyanov, Tinusaur Team. All Rights Reserved.
 * Distributed as open source software under MIT License, see LICENSE.txt file.
 * Please, as a favor, retain the link http://tinusaur.org to The Tinusaur Project.
 *
 * Source code available at: https://bitbucket.org/tinusaur/bmp180tiny
 *
 */

// ============================================================================

// #define F_CPU 1000000UL
// NOTE: The F_CPU (CPU frequency) should not be defined in the source code.
//       It should be defined in either (1) Makefile; or (2) in the IDE. 

#include <stdlib.h>
#include <stdint.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#include "tinyavrlib/cpufreq.h"
#include "owowod/owowod.h"
#include "owowod/debugging.h"
#include "bmp180tiny/bmp180tiny.h"

//
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//                ATtiny
//               25/45/85
//              +----------+   (-)-------
//      (RST)---+ PB5  Vcc +---(+)-------
// --[OWOWOD]---+ PB3  PB2 +---[TWI/SCL]-
//           ---+ PB4  PB1 +---
// -------(-)---+ GND  PB0 +---[TWI/SDA]-
//              +----------+
//
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//

// ----------------------------------------------------------------------------

int main(void) {

	// ---- Initialization ----
	DEBUGGING_INIT();
	DEBUGGING_CRLF(); DEBUGGING_STRINGLN("HELLO[BMP180TINY]");	// Not really needed

	usitwim_init();
	
	uint8_t bmp180_result;
	if ((bmp180_result = bmp180_init()) != BMP180_RESULT_SUCCESS)
	{
		/*DEBUGGING*/ DEBUGGING_ERROR(bmp180_result, "init");
		return -1;
	}

	for (;;) {
		// Read raw temperature
		uint16_t temp_rawdata = bmp180_read_temp_raw();
		/*DEBUGGING*/ DEBUGGING_VARU("t:raw", temp_rawdata);

		uint16_t temp_10x = bmp180_read_temp10x();
		/*DEBUGGING*/ DEBUGGING_VARU("t(dC)", temp_10x);
		// temp_10x holds the result dC, i.e. 123 means 12.3 Celsius
		
		// Read raw pressure
		// int32_t pres_rawdata = bmp180_read_pres_raw();
		// /*DEBUGGING*/ DEBUGGING_VAR("pr/hi", pres_rawdata >> 16);
		// /*DEBUGGING*/ DEBUGGING_VAR("pr/lo", pres_rawdata & 0xffff);
		
		// Read pressure
		int32_t pres = bmp180_read_pres();
		int16_t pres_hpa = pres / 100;
		/*DEBUGGING*/ DEBUGGING_VAR("p(hPa)", pres_hpa);
		// pres_hpa holds the result in hPa (hectopascals)
		
		// Read altitude
		int32_t alt_x = bmp180_read_alt_x();
		int16_t alt_dm = alt_x / 100;
		/*DEBUGGING*/ DEBUGGING_VAR("a(dm)", alt_dm);
		// alt_dm holds the result in dm (decimeters)
		
		_delay_ms(2000);
		/*DEBUGGING*/ DEBUGGING_CRLF();
	}
	
	return 0;
}

// ============================================================================
