BMP180TINY - BMP180 Barometric Pressure/Temperature/Altitude Sensor library

This is a test project.

To make, execute:
	$ make

To upload, execute:
	$ avrdude -c usbasp -p t85 -U flash:w:"main.hex":a


