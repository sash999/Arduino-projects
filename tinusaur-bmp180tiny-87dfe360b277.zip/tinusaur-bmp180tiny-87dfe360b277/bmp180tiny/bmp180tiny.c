/**
 * BMP180TINY - BMP180 Barometric Pressure/Temperature/Altitude Sensor library
 *
 * @created: 2015-03-03
 * @author: Neven Boyanov
 *
 * This is part of the Tinusaur/BMP180TINY project.
 *
 * Copyright (c) 2016 Neven Boyanov, Tinusaur Team. All Rights Reserved.
 * Distributed as open source software under MIT License, see LICENSE.txt file.
 * Please, as a favor, retain the link http://tinusaur.org to The Tinusaur Project.
 *
 * Source code available at: https://bitbucket.org/tinusaur/bmp180tiny
 *
 */

// ============================================================================

#include <stdint.h>
#include <util/delay.h>

#include "../usitwix/usitwim.h"

#include "bmp180tiny.h"

// ----------------------------------------------------------------------------

int16_t bmp180_cal_ac1;
int16_t bmp180_cal_ac2;
int16_t bmp180_cal_ac3;
uint16_t bmp180_cal_ac4;
uint16_t bmp180_cal_ac5;
uint16_t bmp180_cal_ac6;
int16_t bmp180_cal_b1;
int16_t bmp180_cal_b2;
int16_t bmp180_cal_mb;
int16_t bmp180_cal_mc;
int16_t bmp180_cal_md;

uint8_t bmp180_read_reg8(uint8_t reg_addr)
{
	uint8_t buffer[2];
	uint8_t result;

	buffer[1] =	reg_addr;
	usitwim_data_write(BMP180_I2CADDR, buffer, 2);
	
	buffer[1] =	reg_addr;
	usitwim_data_read(BMP180_I2CADDR, buffer, 2);
	result = buffer[1];
	
	return result;
}

uint16_t bmp180_read_reg16(uint8_t reg_addr)
{
	uint8_t buffer[3];
	union result
	{
		uint16_t data16;
		struct
		{
			uint8_t lo;
			uint8_t hi;
		};
	} result;

	buffer[1] =	reg_addr;
	usitwim_data_write(BMP180_I2CADDR, buffer, 2);
	
	buffer[1] =	reg_addr;
	usitwim_data_read(BMP180_I2CADDR, buffer, 3);
	result.hi = buffer[1];
	result.lo = buffer[2];
	
	return result.data16;
}

void bmp180_write_reg8(uint8_t reg_addr, uint8_t reg_data)
{
	uint8_t buffer[3];
	uint8_t result;

	buffer[1] =	reg_addr;
	buffer[2] =	reg_data;
	usitwim_data_write(BMP180_I2CADDR, buffer, 3);
}

uint8_t bmp180_init(void)
{
	uint8_t chipid = bmp180_read_reg8(BMP180_CHIPID_REG);
	if (chipid != BMP180_CHIPID_VALUE) return BMP180_RESULT_FAILURE;
	// Read calibration data
	bmp180_cal_ac1	= bmp180_read_reg16(BMP180_CAL_AC1);
	bmp180_cal_ac2	= bmp180_read_reg16(BMP180_CAL_AC2);
	bmp180_cal_ac3	= bmp180_read_reg16(BMP180_CAL_AC3);
	bmp180_cal_ac4	= bmp180_read_reg16(BMP180_CAL_AC4);
	bmp180_cal_ac5	= bmp180_read_reg16(BMP180_CAL_AC5);
	bmp180_cal_ac6	= bmp180_read_reg16(BMP180_CAL_AC6);
	bmp180_cal_b1	= bmp180_read_reg16(BMP180_CAL_B1);
	bmp180_cal_b2	= bmp180_read_reg16(BMP180_CAL_B2);
	bmp180_cal_mb	= bmp180_read_reg16(BMP180_CAL_MB);
	bmp180_cal_mc	= bmp180_read_reg16(BMP180_CAL_MC);
	bmp180_cal_md	= bmp180_read_reg16(BMP180_CAL_MD);
	return BMP180_RESULT_SUCCESS;
}

uint16_t bmp180_read_temp_raw(void)
{
	bmp180_write_reg8(BMP180_CONTROL, BMP180_READTEMPCMD);
	_delay_ms(5);
	uint16_t temp_rawdata = bmp180_read_reg16(BMP180_TEMPDATA);
	return temp_rawdata;
}

uint16_t bmp180_read_temp10x(void)
{
    int32_t UT, X1, X2, B5;     // following ds convention

    UT = bmp180_read_temp_raw();

    X1 = ((UT - (int32_t)bmp180_cal_ac6) * ((int32_t)bmp180_cal_ac5)) >> 15;
    X2 = ((int32_t)bmp180_cal_mc << 11) / (X1 + (int32_t)bmp180_cal_md);
    B5 = X1 + X2;
    return (B5 + 8) >> 4;
}

uint8_t bmp180_read_temp(void)
{
    return bmp180_read_temp10x() / 10;
}

uint32_t bmp180_read_pres_raw(void)
{
	union pres_raw
	{
		uint32_t data32;
		struct
		{
			uint8_t   lo;
			uint16_t  hi;
			uint8_t   xx;
		};
	} pres_raw;
	
	bmp180_write_reg8(BMP180_CONTROL, BMP180_READPRESSURECMD + (BMP180_OVERSAMPLING << 6));

	// TODO: Take into account the BMP180_OVERSAMPLING
	_delay_ms(26);

	uint16_t raw1 = bmp180_read_reg16(BMP180_PRESSUREDATA);
	uint8_t raw2 = bmp180_read_reg8(BMP180_PRESSUREDATA + 2);
	// /*DEBUGGING*/ DEBUGGING_VARU("pr/raw1", raw1);
	// /*DEBUGGING*/ DEBUGGING_VARU("pr/raw2", raw2);
	
    // pres_raw.data32 = raw1;
    // pres_raw.data32 <<= 8;
    // pres_raw.data32 |= raw2;
    // pres_raw.data32 >>= (8 - BMP180_OVERSAMPLING);
	
	pres_raw.hi = raw1;
	pres_raw.lo = raw2;
    pres_raw.data32 >>= (8 - BMP180_OVERSAMPLING);

	// /*DEBUGGING*/ DEBUGGING_VARU("pr/hi", pres_raw.hi);
	// /*DEBUGGING*/ DEBUGGING_VARU("pr/lo", pres_raw.lo);
	return pres_raw.data32;
}

int32_t bmp180_read_pres(void)
{
    int32_t UT, UP, B3, B5, B6, X1, X2, X3, p;
    uint32_t B4, B7;

    UT = bmp180_read_temp_raw();
    UP = bmp180_read_pres_raw();
    //see manual http://media.digikey.com/pdf/Data%20Sheets/Bosch/BMP085.pdf page 13

    // do temperature calculations
    X1=((UT-(int32_t)(bmp180_cal_ac6))*((int32_t)(bmp180_cal_ac5))) >> 15;
    X2=((int32_t)bmp180_cal_mc << 11)/(X1+(int32_t)bmp180_cal_md);
    B5=X1 + X2;

    // do pressure calcs
    B6 = B5 - 4000;
    X1 = ((int32_t)bmp180_cal_b2 * ( (B6 * B6)>>12 )) >> 11;
    X2 = ((int32_t)bmp180_cal_ac2 * B6) >> 11;
    X3 = X1 + X2;
    B3 = ((((int32_t)bmp180_cal_ac1*4 + X3) << BMP180_OVERSAMPLING) + 2) >> 2;

    X1 = ((int32_t)bmp180_cal_ac3 * B6) >> 13;
    X2 = ((int32_t)bmp180_cal_b1 * ((B6 * B6) >> 12)) >> 16;
    X3 = ((X1 + X2) + 2) >> 2;
    B4 = ((uint32_t)bmp180_cal_ac4 * (uint32_t)(X3 + 32768)) >> 15;
    B7 = ((uint32_t)UP - B3) * (uint32_t)( 50000UL >> BMP180_OVERSAMPLING );

    if (B7 < 0x80000000) {
        p = (B7 << 1) / B4;
    } 
    else {
        p = (B7 / B4) << 1;
    }
    X1 = (p >> 8) * (p >> 8);
    X1 = (X1 * 3038) >> 16;
    X2 = (-7357 * p) >> 16;

    p = p + ((X1 + X2 + (int32_t)3791)>>4);
    return p;
}

int32_t bmp180_read_alt_x(void)
{
    int32_t pressure = bmp180_read_pres();
	
	int32_t moo = (int32_t)95000 - pressure;
	int32_t moo2 = moo * moo;
	int32_t altitude = 540418; //0th term
	altitude += (((int32_t)22455 * moo) >> 8); //1st term
	altitude += (moo2 >> 12) + (moo2 >> 13) + (moo2 >> 17); //2nd term

	// int32_t moo64 = moo >> 6;
	// int32_t moo364 = moo64 * moo64 * moo64;
	// altitude += (moo >> 12) + (moo >> 17) + (moo >> 18); //1st term, extra precision
	// altitude += (moo364 >> 11) + (moo364 >> 13) + (moo364 >> 17) + (moo364 >> 18) + (moo364 >> 21); //3rd term for extra precision
	
    return altitude;
}

// ============================================================================
